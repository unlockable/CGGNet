# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:38:50 2024

@author: HSJ
"""
import matplotlib.pyplot as plt


# New data for compile_num
compile_num1 = {0: 943.1875, 1: 781.4375, 2: 796.0625, 3: 753.125, 4: 766.5625, 5: 695.6875, 6: 680.9375, 7: 677.625, 8: 693.625, 9: 693.375, 10: 660.25, 11: 722.3125, 12: 661.375, 13: 483.375, 14: 644.8125, 15: 728.125, 16: 710.875, 17: 700.75, 18: 716.1875, 19: 642.9375, 20: 564.75, 21: 760.5, 22: 698.0, 23: 725.9375, 24: 683.3125, 25: 770.125, 26: 805.1875, 27: 796.9375, 28: 940.5625, 29: 914.9375}
compile_num2 = {0: 494.9375, 1: 348.0625, 2: 467.6875, 3: 421.75, 4: 501.625, 5: 448.375, 6: 561.125, 7: 398.375, 8: 563.625, 9: 551.25, 10: 523.125, 11: 655.8125, 12: 512.3125, 13: 689.4375, 14: 692.875, 15: 589.125, 16: 615.0, 17: 661.6875, 18: 625.3125, 19: 609.875, 20: 695.6875, 21: 685.6875, 22: 570.1875, 23: 776.625, 24: 674.4375, 25: 736.0625, 26: 690.375, 27: 849.5, 28: 817.75, 29: 892.25}
compile_num3 = {0: 311.4375, 1: 313.25, 2: 311.625, 3: 301.6875, 4: 300.75, 5: 301.8125, 6: 373.0, 7: 328.6875, 8: 366.5, 9: 352.8125, 10: 353.375, 11: 386.75, 12: 338.5625, 13: 344.0, 14: 342.375, 15: 449.375, 16: 348.0625, 17: 437.0, 18: 470.8125, 19: 480.5, 20: 495.625, 21: 488.6875, 22: 523.625, 23: 436.625, 24: 514.1875, 25: 559.6875, 26: 597.0, 27: 544.5, 28: 606.875, 29: 533.625}
compile_num_lstm_400epoch = {}

epochs = list(compile_num1.keys())

# Extracting values for compile_num
compile_values1 = list(compile_num1.values())
compile_values2 = list(compile_num2.values())
compile_values3 = list(compile_num3.values())

# Plotting the graphs for compile_num
plt.figure(figsize=(12, 8))

plt.plot(epochs, compile_values1, label='RNN-based CGGNet', color='blue', linestyle='-', marker='o')
plt.plot(epochs, compile_values2, label='GRU-based CGGNet', color='red', linestyle='--', marker='s')
plt.plot(epochs, compile_values3, label='LSTM-based CGGNet', color='green', linestyle='-.', marker='^')



plt.xlabel('Epoch', fontsize=18)
plt.ylabel('Valid File', fontsize=18)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.legend(fontsize=14)
plt.show()