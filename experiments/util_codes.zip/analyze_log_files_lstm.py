# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 20:14:35 2024

@author: HSJ
"""

from glob import glob

log_files = glob("H:/TextGAN/results_data/revision/LSTM_Improvements/*.log")

epoch_100_loss = []
epoch_200_loss = []
epoch_300_loss = []
epoch_400_loss = []


epoch_100_loss_avg = {}
epoch_200_loss_avg = {}
epoch_300_loss_avg = {}
epoch_400_loss_avg = {}

epoch_100_com_num = []
epoch_200_com_num = []
epoch_300_com_num = []
epoch_400_com_num = []


epoch_100_com_avg = {}
epoch_200_com_avg = {}
epoch_300_com_avg = {}
epoch_400_com_avg = {}

total_epoch = 30
current_epoch = total_epoch

for log_file in log_files :
    f = open(log_file)
    lines = f.readlines()
    flag = False
    idx = 0
        
    current_epoch = -1
    compile_num = 0
    
    for line in lines :
        if "ADV EPOCH" in line :
            flag = True            
            current_epoch += 1
        if "the number of compilable_tokens" in line :
            compile_num = int(line.split(":")[1])
        if "self.adv_dataloader num" in line and flag == True :                       
            #print(line)
                
            if "100" in log_file :
                epoch_100_com_num.append(compile_num)
            elif "200" in log_file :
                epoch_200_com_num.append(compile_num)
            elif "300" in log_file :
                epoch_300_com_num.append(compile_num)
            elif "400" in log_file :
                epoch_400_com_num.append(compile_num)    
                                

        if "[MLE-GEN] epoch" in line and flag == True :
            #print(line)
            loss = float(line.split("=")[1].replace("\n", "").replace(" ", ""))
            idx += 1
            if compile_num == 0:
                if "100" in log_file :
                    epoch_100_loss.append(0)
                    epoch_100_com_num.append(0)
                elif "200" in log_file :
                    epoch_200_loss.append(0)
                    epoch_200_com_num.append(0)
                elif "300" in log_file :
                    epoch_300_loss.append(0)   
                    epoch_300_com_num.append(0)
                elif "400" in log_file :
                    epoch_400_loss.append(0)   
                    epoch_400_com_num.append(0)
                continue
            
            if idx % 2 == 0 :
                if "100" in log_file :
                    epoch_100_loss.append(loss)
                elif "200" in log_file :
                    epoch_200_loss.append(loss)
                elif "300" in log_file :
                    epoch_300_loss.append(loss)
                elif "400" in log_file :
                    epoch_400_loss.append(loss)
                    
for i in range(total_epoch) :
    epoch_100_loss_avg[i] = 0
    epoch_200_loss_avg[i] = 0
    epoch_300_loss_avg[i] = 0
    epoch_400_loss_avg[i] = 0
    
print(len(epoch_300_loss))
for i in range(len(epoch_100_loss)) :
    epoch_100_loss_avg[i % total_epoch] += epoch_100_loss[i]
    epoch_200_loss_avg[i % total_epoch] += epoch_200_loss[i]
    epoch_300_loss_avg[i % total_epoch] += epoch_300_loss[i]
    epoch_400_loss_avg[i % total_epoch] += epoch_400_loss[i]
            
for i in range(total_epoch) :
    epoch_100_loss_avg[i] /= 16
    epoch_200_loss_avg[i] /= 16
    epoch_300_loss_avg[i] /= 16
    epoch_400_loss_avg[i] /= 16


for i in range(total_epoch) :
    epoch_100_com_avg[i] = 0
    epoch_200_com_avg[i] = 0
    epoch_300_com_avg[i] = 0
    epoch_400_com_avg[i] = 0

for i in range(len(epoch_100_loss)) :
    epoch_100_com_avg[i % total_epoch] += epoch_100_com_num[i]
    epoch_200_com_avg[i % total_epoch] += epoch_200_com_num[i]
    epoch_300_com_avg[i % total_epoch] += epoch_300_com_num[i]
    epoch_400_com_avg[i % total_epoch] += epoch_400_com_num[i]

for i in range(total_epoch) :
    epoch_100_com_avg[i] /= 16
    epoch_200_com_avg[i] /= 16
    epoch_300_com_avg[i] /= 16
    epoch_400_com_avg[i] /= 16


print("losses :")
print(len(epoch_100_loss))
print(len(epoch_200_loss))
print(len(epoch_300_loss))    
print(len(epoch_400_loss))    
    

print((epoch_100_loss_avg))
print((epoch_200_loss_avg))
print((epoch_300_loss_avg))    
print((epoch_400_loss_avg))    


print("compiled files :")

print(len(epoch_100_com_num))
print(len(epoch_200_com_num))
print(len(epoch_300_com_num))
print(len(epoch_400_com_num))

print((epoch_100_com_avg))
print((epoch_200_com_avg))
print((epoch_300_com_avg))
print((epoch_400_com_avg))


