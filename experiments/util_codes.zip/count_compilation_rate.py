# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 20:14:35 2024

@author: HSJ
"""

from glob import glob

log_files = glob("H:/TextGAN/results_data/revision/logs/*.log")

rnn_loss = []
gru_loss = []
lstm_loss = []

rnn_loss_avg = {}
gru_loss_avg = {}
lstm_loss_avg = {}

rnn_com_num = []
gru_com_num = []
lstm_com_num = []


rnn_com_avg = {}
gru_com_avg = {}
lstm_com_avg = {}

total_epoch = 30
current_epoch = total_epoch

rnn_max_len_sum = 0
rnn_compile_num_sum = 0 

gru_max_len_sum = 0
gru_compile_num_sum = 0 

lstm_max_len_sum = 0
lstm_compile_num_sum = 0 


for log_file in log_files :
    f = open(log_file)
    lines = f.readlines()
    last_epoch_flag = False
    first_epoch_flag = False
    idx = 0
        
    current_epoch = -1
    compile_num = 0
    
    for line in lines :
        if "ADV EPOCH 29" in line :
            last_epoch_flag = True            
        if "ADV EPOCH 0" in line :
            first_epoch_flag = True  
        elif "ADV EPOCH" in line and first_epoch_flag == True:
            first_epoch_flag = False  
        
        if last_epoch_flag != True :
            continue
        '''
        if first_epoch_flag != True :
            continue
        '''
        if "max len" in line :
            max_len_sum = int(line.split(":")[1].strip())
            if "rnn" in log_file :
                rnn_max_len_sum += max_len_sum
            elif "gru" in log_file :
                gru_max_len_sum += max_len_sum
            else :
                lstm_max_len_sum += max_len_sum

        if "compiled_num" in line :
            compile_num_sum = int(line.split(":")[1].strip())
            if "rnn" in log_file :
                rnn_compile_num_sum += compile_num_sum
            elif "gru" in log_file :
                gru_compile_num_sum += compile_num_sum
            else :
                lstm_compile_num_sum += compile_num_sum

rnn_compliation_rate = rnn_compile_num_sum / (rnn_max_len_sum * 128)
gru_compliation_rate = gru_compile_num_sum / (gru_max_len_sum * 128)
lstm_compliation_rate = lstm_compile_num_sum / (lstm_max_len_sum * 128)
                    
print(rnn_max_len_sum * 128)
print(gru_max_len_sum * 128)
print(lstm_max_len_sum * 128)

print(rnn_compile_num_sum)
print(gru_compile_num_sum)
print(lstm_compile_num_sum)

print(rnn_compliation_rate)
print(gru_compliation_rate)
print(lstm_compliation_rate)
