import os
from tqdm import tqdm
def merge_sol_files(source_dir, output_file):
    with open(output_file, 'w') as outfile:
        for root, dirs, files in os.walk(source_dir):
            for file in tqdm(files):
                if file.endswith('.sol'):
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r') as infile:
                        outfile.write(infile.read())

# Specify the directory to search for .sol files and the output file name
#source_directory = "H:\\TextGAN\\results_data\\revision\\CGGNet\\200epochs"  # Change this to your directory path
source_directory = "H:\\TextGAN\\results_data\\revision\\CGGNet\\200epochs\\"

output_filename = "200_epochs_merged_output.txt"       # Change this as needed

merge_sol_files(source_directory, output_filename)

