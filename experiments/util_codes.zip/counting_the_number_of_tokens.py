import os
from tqdm import tqdm
from glob import glob

log_files = glob("H:\\TextGAN\\results_data\\experiments\\logs\\*.log")
rnn_tokens_num_avg_list = []
gru_tokens_num_avg_list = []
lstm_tokens_num_avg_list = []

def sort_files_by_timestamp(folder_path):
    # List all file paths in the current folder
    files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".txt") or f.endswith(".sol")] 
    # Sort files by their last modification time; oldest first
    files.sort(key=lambda x: os.path.getmtime(x))
    return files

def count_tokens_in_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        tokens = content.split()  # Splits the content by whitespace to tokenize
        return len(tokens)

def process_folder(folder_path):
    total_tokens = 0
    sorted_files = sort_files_by_timestamp(folder_path)
    token_num_list = []
    for file_path in tqdm(sorted_files):
        tokens_count = count_tokens_in_file(file_path)
        total_tokens += tokens_count
        token_num_list.append(tokens_count)
        #print(f"{file_path}: {tokens_count} tokens")

    print(f"Total tokens in {folder_path}: {total_tokens}")

    return token_num_list


for log_file in log_files :
    com_num_list = []

    folder_path = 'H:\\TextGAN\\results_data\\normal_target\\' + log_file.split("\\")[-1].replace(".log", "")
    print(folder_path)

    token_num_list =  process_folder(folder_path)
    f = open(log_file)
    lines = f.readlines()
    flag = False
    idx = 0
        
    current_epoch = -1
    compile_num = 0
    
    for line in lines :
        
        if "ADV EPOCH" in line :
            flag = True            
            pre_train_flag = False
            current_epoch += 1
        if "the number of compilable_tokens" in line :
            compile_num = int(line.split(":")[1])
                
        if "self.adv_dataloader num" in line and flag == True :                       
            #print(line)
                
            com_num_list.append(compile_num)
            
                                                
        if "[MLE-GEN] epoch" in line and flag == True :
            #print(line)
            loss = float(line.split("=")[1].replace("\n", "").replace(" ", ""))
            idx += 1
            if compile_num == 0:
                com_num_list.append(0)

                
    start_idx = 0
    for i in range(len(com_num_list)) :
        sum_of_epoch_tokens = sum(token_num_list[start_idx : start_idx + com_num_list[i]])
        if com_num_list[i] == 0 :
            avg_of_epoch_tokens = 0
        else :
            avg_of_epoch_tokens = sum_of_epoch_tokens / com_num_list[i]
            
            
        if "rnn" in folder_path :
            rnn_tokens_num_avg_list.append(avg_of_epoch_tokens)
        if "gru" in folder_path :
            gru_tokens_num_avg_list.append(avg_of_epoch_tokens)
        if "lstm" in folder_path :
            lstm_tokens_num_avg_list.append(avg_of_epoch_tokens)
       
        start_idx += com_num_list[i]
    

total_epoch = 30
exper_num = 12
rnn_token_avg = {}
gru_token_avg = {}
lstm_token_avg = {}

for i in range(total_epoch) :
    rnn_token_avg[i] = 0
    gru_token_avg[i] = 0
    lstm_token_avg[i] = 0

for i in range(len(gru_tokens_num_avg_list)) :
    rnn_token_avg[i % total_epoch] += rnn_tokens_num_avg_list[i]
    gru_token_avg[i % total_epoch] += gru_tokens_num_avg_list[i]
    lstm_token_avg[i % total_epoch] += lstm_tokens_num_avg_list[i]

for i in range(total_epoch) :
    rnn_token_avg[i] /= exper_num
    gru_token_avg[i] /= exper_num
    lstm_token_avg[i] /= exper_num
    

print(rnn_token_avg)
print(gru_token_avg)
print(lstm_token_avg)
'''
folder_path = 'H:\\TextGAN\\results_data\\normal_target\\normal_gru5\\'  # Replace this with the path to your folder
process_all_folders(folder_path)
'''