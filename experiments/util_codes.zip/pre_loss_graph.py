# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:38:50 2024

@author: HSJ
"""
import matplotlib.pyplot as plt



# New data for compile_num
pre_loss_rnn = {1: 0.8242750000000001, 2: 0.36818333333333336, 3: 0.2658416666666667, 4: 0.21817499999999998, 5: 0.1879666666666667, 6: 0.16315000000000002, 7: 0.14276666666666668, 8: 0.1262, 9: 0.11280833333333333, 10: 0.10096666666666666, 11: 0.09080833333333332, 12: 0.082525, 13: 0.07614166666666668, 14: 0.07040833333333334, 15: 0.06592500000000001, 16: 0.061949999999999984, 17: 0.05888333333333332, 18: 0.05660833333333332, 19: 0.054225, 20: 0.0524}
pre_loss_gru = {1: 0.8634416666666667, 2: 0.701425, 3: 0.4539583333333333, 4: 0.29505833333333326, 5: 0.22518333333333332, 6: 0.18666666666666668, 7: 0.15963333333333332, 8: 0.1396166666666667, 9: 0.12238333333333333, 10: 0.10842500000000001, 11: 0.09724166666666666, 12: 0.08771666666666667, 13: 0.08010833333333334, 14: 0.07338333333333334, 15: 0.068225, 16: 0.06372499999999999, 17: 0.06015, 18: 0.05704166666666668, 19: 0.054233333333333335, 20: 0.052741666666666666}
pre_loss_lstm = {1: 1.0735249999999998, 2: 0.7870166666666666, 3: 0.6601750000000001, 4: 0.5309750000000001, 5: 0.4357166666666667, 6: 0.37328333333333324, 7: 0.3293, 8: 0.29729999999999995, 9: 0.2709583333333333, 10: 0.25026666666666664, 11: 0.23283333333333334, 12: 0.21682500000000002, 13: 0.2043916666666666, 14: 0.19220833333333334, 15: 0.17980833333333335, 16: 0.16963333333333333, 17: 0.16183333333333333, 18: 0.15170000000000003, 19: 0.1438, 20: 0.137325}

epochs = list(i * 10 for i in range(20))
# Extracting values for compile_num
pre_loss_rnn_values = list(pre_loss_rnn.values())
pre_loss_gru_values = list(pre_loss_gru.values())
pre_loss_lstm_values = list(pre_loss_lstm.values())

# Plotting the graphs for compile_num
plt.figure(figsize=(12, 8))

plt.plot(epochs, pre_loss_rnn_values, label='RNN-based CGGNet', color='blue', linestyle='-', linewidth=2, marker='o')
plt.plot(epochs, pre_loss_gru_values, label='GRU-based CGGNet', color='red', linestyle='--', linewidth=2, marker='s')
plt.plot(epochs, pre_loss_lstm_values, label='LSTM-based CGGNet', color='green', linestyle='-.', linewidth=2, marker='^')

plt.xlabel('Epoch', fontsize=22)
plt.ylabel('Pre-train loss', fontsize=22)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

plt.legend(fontsize=18)
plt.grid(True)
plt.tight_layout()
plt.show()
