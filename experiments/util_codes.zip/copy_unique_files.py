import os
import shutil
import hashlib
from glob import glob
from tqdm import tqdm 

def sha256sum(filename):
    h  = hashlib.sha256()
    with open(filename, 'rb') as file:
        for block in iter(lambda: file.read(4096), b''):
            h.update(block)
    return h.hexdigest()

def copy_unique_files(target_root_folder, destination_folder):
    unique_files = set()

    for root, dirs, files in os.walk(target_root_folder):
        for file in tqdm(files):
            file_path = os.path.join(root, file)
            file_hash = sha256sum(file_path)

            if file_hash not in unique_files:
                unique_files.add(file_hash)
                destination_path = os.path.join(destination_folder, file)
                shutil.copy2(file_path, destination_path)
                #print(f"Copied: {file_path} -> {destination_path}")


target_root_folder  = "H:\\TextGAN\\results_data\\revision\\CGGNet\\results"

destination_folder  = 'H:\\TextGAN\\results_data\\20240320_results'

copy_unique_files(target_root_folder, destination_folder)

'''
unique_hashes = set()

for folder in tqdm(folders) :
    source_directory = folder

    for filename in os.listdir(source_directory):
        source_filepath = os.path.join(source_directory, filename)
        if os.path.isfile(source_filepath):
            file_hash = sha256sum(source_filepath)
            if file_hash not in unique_hashes:
                unique_hashes.add(file_hash)
                destination_filepath = os.path.join(destination_directory, file_hash)
                shutil.copy2(source_filepath, destination_filepath)
'''
print(f"Copied {len(unique_hashes)} unique files.")
